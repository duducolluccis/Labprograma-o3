//Eduardo Collucci dos Santos Cod: 831485
package Biblioteca;

import java.time.LocalDate;

public class Empréstimos {
    
     private int id;
     private int idUsuario;
     private int idLivro;
     private LocalDate dataEmprestimo;
     private LocalDate dataDevolucao;
     private String Devolvido;

    public Empréstimos() {
    }

    public Empréstimos(int id, int idUsuario, int idLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, String Devolvido) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.Devolvido = Devolvido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public String isDevolvido() {
        return Devolvido;
    }

    public void setDevolvido(String Devolvido) {
        this.Devolvido = Devolvido;
    }

    @Override
    public String toString() {
        return  "\nId do Emprestimo:" + id + "\nID doUsuario:" + idUsuario + "\nID do Livro:" + idLivro + "\nData do Emprestimo:" + dataEmprestimo + "\nData da Devolucao=" + dataDevolucao + "\nData Devolvido=:" + Devolvido;
    }

     
}
