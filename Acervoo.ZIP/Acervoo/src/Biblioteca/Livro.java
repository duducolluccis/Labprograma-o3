//Eduardo Collucci dos Santos Cod: 831485
package Biblioteca;


public class Livro {
    
    private int id;
    private String titulo; 
    private String autor;
    private String edicao;
    private String editora;
    private String cidade;
    private int anopublicacao;

    public Livro() {
    }

    public Livro(int id, String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
        this.anopublicacao = anopublicacao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEdicao() {
        return edicao;
    }

    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getAnopublicacao() {
        return anopublicacao;
    }

    public void setAnopublicacao(int anopublicacao) {
        this.anopublicacao = anopublicacao;
    }

    @Override
    public String toString() {
        return  "\nId do Livro:" + id + "\nTítulo:" + titulo + "\nAutor=" + autor + "\nEdição:=" + edicao + "\nEditora=" + editora + "\nCidade=" + cidade + "\nAno de Publicão:" + anopublicacao ;
    }

    
    

}
