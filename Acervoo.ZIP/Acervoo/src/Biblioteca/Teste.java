//Eduardo Collucci dos Santos Cod: 831485
package Biblioteca;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;


public class Teste {

    public static void main(String[] args) {
         
     List<Usuario> Usuarios = new ArrayList <> ();
     List<Livro> livros = new ArrayList <> ();
     List<Empréstimos> emprestimo = new ArrayList <> ();
     
     Usuarios.add(new Usuario(831485, "Eduardo", "duducolluccis11@hotmail.com","edu2606"));
     Usuarios.add(new Usuario(831495, "Felipe", "felipemacedo@hotmail.com","felipe1575"));
     Usuarios.add(new Usuario(831455, "Joao Pedro", "joaopedro1@hotmail.com","jao3454"));
     Usuarios.add(new Usuario(836432, "Paulo", "Paulodasilva@hotmail.com","paulim3456"));
     Usuarios.add(new Usuario(876485, "Deyde", "Deydesilva@hotmail.com","deyde893453"));
     
     livros.add(new Livro(01, "Memórias Póstumas de Brás Cubas", "Machado de Assis", "1", "Oxford University Press", "Rio de Janeiro", 1881));
     livros.add(new Livro(02, "A revolução dos bichos", "George Orwell", "1", "Grupo Companhia das Letras", "Portugal", 1945
));
     livros.add(new Livro(03, "Iracema", "José de Alencar", "1", "Typ. de Viana & Filhos", "Sao Paulo", 1865));
      
      emprestimo.add(new Empréstimos(3456,831485,01,LocalDate.of(2020, Month.JUNE,24),LocalDate.of(2020, Month.JULY,24),"Sim"));
      emprestimo.add(new Empréstimos(4578,831495,02,LocalDate.of(2020, Month.JANUARY,05),LocalDate.of(2020, Month.FEBRUARY,05),"Sim"));
      emprestimo.add(new Empréstimos(7856,831455,03,LocalDate.of(2020, Month.JULY,29),LocalDate.of(2020, Month.AUGUST,29),"Sim"));
      emprestimo.add(new Empréstimos(3467,836432,02,LocalDate.of(2020, Month.NOVEMBER,03),LocalDate.of(2020, Month.DECEMBER,03),"Sim"));
      emprestimo.add(new Empréstimos(8723,876485,03,LocalDate.of(2020, Month.AUGUST,30),LocalDate.of(2020, Month.SEPTEMBER,30),"Sim"));
   
      Usuarios.forEach((c) -> {
            System.out.println(c);
        });
      
      livros.forEach((c) -> {
            System.out.println(c);
        });
      
      emprestimo.forEach((c) -> {
            System.out.println(c);
        });
    }
    
}
