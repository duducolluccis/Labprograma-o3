//Eduardo Collucci dos Santos     Codigo: 831485

package exame;

   import java.util.ArrayList;
import java.util.List;
 
public class imobiliaria {
   


    private String txt1;
    private String txt2;
    private String txt3;
    private String txt4;
    private String txt5;

    public imobiliaria() {
    }

    public imobiliaria(String txt1, String txt2, String txt3,String txt4, String txt5) {
        this.txt1 = txt1;
        this.txt2 = txt2;
        this.txt3 = txt3;
        this.txt4 = txt4;
        this.txt5 = txt5;
    }

    public String getTipo() {
        return txt4;
    }

    public void setTipo(String tipo) {
        this.txt4 = tipo;
    }

    public String getCategoria() {
        return txt5;
    }

    public void setCategoria(String categoria) {
        this.txt5 = categoria;
    }

    public String getNome() {
        return txt1;
    }

    public void setNome(String nome) {
        this.txt1 = nome;
    }

    public String getDescricao() {
        return txt2;
    }

    public void setDescricao(String descricao) {
        this.txt2 = descricao;
    }

    public String getVlrvenda() {
        return txt3;
    }

    public void setVlrvenda(String vlrvenda) {
        this.txt3 = vlrvenda;
    }

    public List<String> getDados() {
        return imobiliaria;
    }

    public void setImovel(List<String> imobiliaria) {
        this.imobiliaria = imobiliaria;
    }
    static List<String>imobiliaria = new ArrayList<>();
    
}
 

