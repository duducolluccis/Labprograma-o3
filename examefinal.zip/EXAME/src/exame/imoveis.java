//Eduardo Collucci dos Santos     Codigo: 831485
package exame;

import java.util.ArrayList;
import java.util.List;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;


public class imoveis extends javax.swing.JFrame {
    
private imobiliaria imobiliaria;
java.util.List <imobiliaria> cadastro = new ArrayList ();
   public imoveis() {
        initComponents();
   configForm();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        lblDescrição = new javax.swing.JLabel();
        scpDescrição = new javax.swing.JScrollPane();
        txtDescrição = new javax.swing.JTextArea();
        lblCategoria = new javax.swing.JLabel();
        btnCategoria1 = new javax.swing.JRadioButton();
        btnCategoria2 = new javax.swing.JRadioButton();
        lblTipo = new javax.swing.JLabel();
        cbxitem = new javax.swing.JComboBox<>();
        lblValorVenda = new javax.swing.JLabel();
        txtValorVenda = new javax.swing.JTextField();
        btnAdicionar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblNome.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblNome.setText("Nome:");

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        lblDescrição.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblDescrição.setText("Descrição:");

        txtDescrição.setColumns(20);
        txtDescrição.setRows(5);
        scpDescrição.setViewportView(txtDescrição);

        lblCategoria.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblCategoria.setText("Categoria:");

        btnCategoria1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnCategoria1.setText("Residencial");
        btnCategoria1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCategoria1ActionPerformed(evt);
            }
        });

        btnCategoria2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnCategoria2.setText("Comercial");
        btnCategoria2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCategoria2ActionPerformed(evt);
            }
        });

        lblTipo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTipo.setText("Tipo:");

        cbxitem.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        cbxitem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbxitem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxitemActionPerformed(evt);
            }
        });

        lblValorVenda.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblValorVenda.setText("Valor de venda:");

        txtValorVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtValorVendaActionPerformed(evt);
            }
        });

        btnAdicionar.setText("Adicionar");
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNome)
                    .addComponent(scpDescrição)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnAdicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDescrição)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblValorVenda)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtValorVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblCategoria)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnCategoria2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnCategoria1)
                                .addGap(28, 28, 28)
                                .addComponent(lblTipo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbxitem, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblNome, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblNome, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDescrição)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(scpDescrição, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCategoria)
                    .addComponent(btnCategoria2)
                    .addComponent(lblTipo)
                    .addComponent(cbxitem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCategoria1))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtValorVenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblValorVenda))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAdicionar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCategoria1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoria1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCategoria1ActionPerformed

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarActionPerformed
        imobiliaria imobiliaria = new imobiliaria();
        imobiliaria.setNome(txtNome.getText());
        imobiliaria.setDescricao(txtDescrição.getText());
        String tipo = (String)cbxitem.getSelectedItem();
        imobiliaria.setTipo(tipo);
        String categoria = "";
        if(btnCategoria2.isSelected()){
            categoria = "Comercial";
        }else if(btnCategoria1.isSelected()){
            categoria = "Residencial";
        }
        imobiliaria.setCategoria(categoria);
        imobiliaria.setVlrvenda(txtValorVenda.getText());
        cadastro.add(imobiliaria);
        visualizar v1 = new visualizar();
        v1.setVisible(true);
        v1.recdados(imobiliaria);
        JOptionPane.showMessageDialog(null,"Cadastrado com sucesso");
    }//GEN-LAST:event_btnAdicionarActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btnCategoria2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCategoria2ActionPerformed
        
    }//GEN-LAST:event_btnCategoria2ActionPerformed

    private void cbxitemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxitemActionPerformed
       
    }//GEN-LAST:event_cbxitemActionPerformed

    private void txtValorVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtValorVendaActionPerformed
        
    }//GEN-LAST:event_txtValorVendaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(imoveis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(imoveis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(imoveis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(imoveis.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new imoveis().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JRadioButton btnCategoria1;
    private javax.swing.JRadioButton btnCategoria2;
    private javax.swing.JComboBox<String> cbxitem;
    private javax.swing.JLabel lblCategoria;
    private javax.swing.JLabel lblDescrição;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblValorVenda;
    private javax.swing.JScrollPane scpDescrição;
    private javax.swing.JTextArea txtDescrição;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtValorVenda;
    // End of variables declaration//GEN-END:variables
 
private void configForm() {
    
    this.setTitle("Imobiliaria");
    this.setResizable(false);
    this.setLocationRelativeTo(null);
    cbxitem.setModel(new DefaultComboBoxModel());
    
    ButtonGroup bg = new ButtonGroup();
        bg.add(btnCategoria1);
        bg.add(btnCategoria2);
        btnCategoria1.setSelected(true);
        
        List<String> dados = new ArrayList<>();
        dados.add("Apartamento");
        dados.add("Sítio");
        dados.add("Chácara");
        dados.add("Casa");
        dados.add("Sala");
        dados.add("Salão");
        DefaultComboBoxModel c = new DefaultComboBoxModel();
         for(String elem : dados){
            c.addElement(elem);
        }
        cbxitem.setModel(c);
        
     
    }
}
