//Eduardo Collucci dos Santos     Codigo: 831485

package exame;

import javax.swing.table.DefaultTableModel;


public class visualizar extends javax.swing.JFrame {
    
    private imobiliaria imobiliaria;
    
    public visualizar() {
        initComponents();
        conftabela();
        conf();
    
    }
    
    private void conftabela(){
        
        DefaultTableModel e = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row,int column ){
                return false;
            }
        };
        
        e.addColumn("Nome");
        e.addColumn("Descrição");
        e.addColumn("Categoria");
        e.addColumn("Tipo");
        e.addColumn("Valor(R$)");
        tabimobiliaria.setModel(e);
         }
    
    public void recdados(imobiliaria imobiliaria){
        
        String nome = imobiliaria.getNome();
        String descrição = imobiliaria.getDescricao();
        String valor = imobiliaria.getVlrvenda();
        String tipo = imobiliaria.getTipo();
        String categoria = imobiliaria.getCategoria();
         if(!nome.isEmpty()){
            DefaultTableModel m = (DefaultTableModel)tabimobiliaria.getModel();
            m.addRow(new String[]{nome,descrição,categoria,tipo,valor});
            tabimobiliaria.setModel(m);
                                
    }
    }
    private void conf(){
        this.setTitle("Visualizar Imóveis");
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }
    
             

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabimobiliaria = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tabimobiliaria.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabimobiliaria);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 472, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(visualizar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(visualizar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(visualizar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(visualizar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new visualizar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabimobiliaria;
    // End of variables declaration//GEN-END:variables
}
